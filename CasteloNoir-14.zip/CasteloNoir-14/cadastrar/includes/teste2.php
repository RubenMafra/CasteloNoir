<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;  
use PHPMailer\PHPMailer\Exception;  

require "PHPMailer/src/Exception.php";
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";

if(isset($_POST['cadastrar'])) 
{
$nome  = $conexao->escape_string(trim($_POST["nome"]));
$data = $conexao->escape_string(trim($_POST["data_aniver"]));
$email = $conexao->escape_string(trim($_POST["email"]));

$sql = "INSERT $nomeDaTabela VALUES(
               null,
              '$nome',
              '$data',
              '$email')";

$conexao->query($sql) or exit($conexao->error);

$mail = new PHPMailer(true);

    try {
        // Configuração do servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'sandbox.smtp.mailtrap.io';  // Substitua com o seu servidor SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'b04623cddfa355'; // Seu e-mail
        $mail->Password = '60a317876315e1'; // Sua senha de e-mail
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587; // Porta para TLS

        // Definição do remetente e do destinatário
        $mail->setFrom("castelo.noir@gmail.com", "Castelo Noir");
        $mail->addAddress($email, $nome); // E-mail do destinatário

        // Conteúdo do e-mail
        $mail->isHTML(true);
        $mail->Subject = 'Cadastro realizado com sucesso!';
        $mail->Body    = "Olá $nome, seu cadastro foi realizado com sucesso no nosso sistema!";
        
        // Envia o e-mail
        $mail->send();
        header("location: ../../inicio/inicio.php");
        echo '';
    } catch (Exception $e) {
        echo "Erro ao enviar o e-mail: {$mail->ErrorInfo}";
    }
}

?>