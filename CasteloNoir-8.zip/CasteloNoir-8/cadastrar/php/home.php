<!DOCTYPE html> 
<html lang="pt-BR"> 
<head> 
  <meta charset="utf-8"> 
  <title> Login de usuário com PHP </title>
  <link rel="stylesheet" href="../css/formata-login.css">
</head> 

<body> 
    <h1> Autenticação de usuário com PHP - HOME</h1>
    
    <div>
      <a href="formulario-cadastro.php"> Ir para o cadastro de administrador</a>
      <a href="formulario-login"> Ir para a área de login do administrador </a>
    </div>
</body> 
</html> 