<?php
$conexao->close();